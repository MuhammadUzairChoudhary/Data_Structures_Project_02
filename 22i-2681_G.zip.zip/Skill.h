#pragma once
//Muhammad_Uzair_Choudhary_22i2681
#include<iostream>
using namespace std;

class Skill
{
public:
	int id;
	float Proficiency;
	string name;

};