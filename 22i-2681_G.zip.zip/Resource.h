#pragma once
//Muhammad_Uzair_Choudhary_22i2681
#include<iostream>
#include"Skill.h"

using namespace std;

class Resource
{
public:
	Skill* skill;
	Resource* next;
	int id;

};